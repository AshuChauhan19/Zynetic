-- Schema for Fleet ingestion assessment

-- Vehicle history (append-only)
CREATE TABLE IF NOT EXISTS vehicle_history (
  id bigserial PRIMARY KEY,
  vehicle_id text NOT NULL,
  soc numeric,
  kwh_delivered_dc numeric NOT NULL,
  battery_temp numeric,
  ts timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS vehicle_history_vehicle_ts_idx ON vehicle_history(vehicle_id, ts);

-- Meter history (append-only)
CREATE TABLE IF NOT EXISTS meter_history (
  id bigserial PRIMARY KEY,
  meter_id text NOT NULL,
  kwh_consumed_ac numeric NOT NULL,
  voltage numeric,
  ts timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS meter_history_meter_ts_idx ON meter_history(meter_id, ts);

-- Live tables (single row per entity, upsert)
CREATE TABLE IF NOT EXISTS vehicle_live (
  vehicle_id text PRIMARY KEY,
  soc numeric,
  kwh_delivered_dc numeric,
  battery_temp numeric,
  ts timestamptz
);

CREATE TABLE IF NOT EXISTS meter_live (
  meter_id text PRIMARY KEY,
  kwh_consumed_ac numeric,
  voltage numeric,
  ts timestamptz
);

-- Hourly aggregates to avoid scanning history for analytics
CREATE TABLE IF NOT EXISTS hourly_aggregates (
  id bigserial PRIMARY KEY,
  entity_type text NOT NULL, -- 'vehicle' | 'meter'
  entity_id text NOT NULL,
  hour_ts timestamptz NOT NULL,
  sum_kwh numeric DEFAULT 0,
  sum_battery_temp numeric DEFAULT 0,
  cnt bigint DEFAULT 0,
  UNIQUE(entity_type, entity_id, hour_ts)
);
CREATE INDEX IF NOT EXISTS hourly_aggregates_entity_idx ON hourly_aggregates(entity_type, entity_id, hour_ts);

-- Mapping between meters and vehicles during charging sessions. This allows correlating AC (meter) with DC (vehicle).
CREATE TABLE IF NOT EXISTS meter_assignments (
  meter_id text PRIMARY KEY,
  vehicle_id text,
  active boolean DEFAULT TRUE,
  updated_at timestamptz DEFAULT now()
);
