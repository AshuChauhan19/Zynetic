import { query } from '../config/db.js';

const hourTrunc = (date) => {
  const d = new Date(date);
  d.setMinutes(0, 0, 0);
  return d.toISOString();
};

export async function handleMeter({ meterId, kwhConsumedAc, voltage, timestamp }) {
  await query(`INSERT INTO meter_history(meter_id, kwh_consumed_ac, voltage, ts) VALUES($1,$2,$3,$4)`, [meterId, kwhConsumedAc, voltage, timestamp]);

  await query(`INSERT INTO meter_live(meter_id, kwh_consumed_ac, voltage, ts)
    VALUES($1,$2,$3,$4) ON CONFLICT (meter_id) DO UPDATE SET kwh_consumed_ac = EXCLUDED.kwh_consumed_ac, voltage = EXCLUDED.voltage, ts = EXCLUDED.ts`,
    [meterId, kwhConsumedAc, voltage, timestamp]);

  const hour = hourTrunc(timestamp);
  await query(`INSERT INTO hourly_aggregates(entity_type, entity_id, hour_ts, sum_kwh)
    VALUES('meter',$1,$2,$3) ON CONFLICT (entity_type, entity_id, hour_ts) DO UPDATE SET sum_kwh = hourly_aggregates.sum_kwh + EXCLUDED.sum_kwh`,
    [meterId, hour, kwhConsumedAc]);
}

export async function handleVehicle({ vehicleId, soc, kwhDeliveredDc, batteryTemp, timestamp }) {
  await query(`INSERT INTO vehicle_history(vehicle_id, soc, kwh_delivered_dc, battery_temp, ts) VALUES($1,$2,$3,$4,$5)`, [vehicleId, soc, kwhDeliveredDc, batteryTemp, timestamp]);

  await query(`INSERT INTO vehicle_live(vehicle_id, soc, kwh_delivered_dc, battery_temp, ts)
    VALUES($1,$2,$3,$4,$5) ON CONFLICT (vehicle_id) DO UPDATE SET soc = EXCLUDED.soc, kwh_delivered_dc = EXCLUDED.kwh_delivered_dc, battery_temp = EXCLUDED.battery_temp, ts = EXCLUDED.ts`,
    [vehicleId, soc, kwhDeliveredDc, batteryTemp, timestamp]);

  const hour = hourTrunc(timestamp);
  await query(`INSERT INTO hourly_aggregates(entity_type, entity_id, hour_ts, sum_kwh, sum_battery_temp, cnt)
    VALUES('vehicle',$1,$2,$3,$4,1) ON CONFLICT (entity_type, entity_id, hour_ts) DO UPDATE SET
      sum_kwh = hourly_aggregates.sum_kwh + EXCLUDED.sum_kwh,
      sum_battery_temp = hourly_aggregates.sum_battery_temp + EXCLUDED.sum_battery_temp,
      cnt = hourly_aggregates.cnt + 1`,
    [vehicleId, hour, kwhDeliveredDc, batteryTemp]);
}
