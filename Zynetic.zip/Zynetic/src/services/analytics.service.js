import { query } from '../config/db.js';

export async function performance24h(vehicleId) {
  const now = new Date();
  const from = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
  const to = now.toISOString();

  const dcRes = await query(`SELECT COALESCE(SUM(sum_kwh),0) AS total_dc, 
    CASE WHEN COALESCE(SUM(cnt),0)>0 THEN SUM(sum_battery_temp)::float / SUM(cnt) ELSE NULL END AS avg_battery_temp
    FROM hourly_aggregates
    WHERE entity_type='vehicle' AND entity_id=$1 AND hour_ts >= $2 AND hour_ts <= $3`, [vehicleId, from, to]);

  const { total_dc, avg_battery_temp } = dcRes.rows[0];

  const assignRes = await query(`SELECT meter_id FROM meter_assignments WHERE vehicle_id=$1 AND active=TRUE`, [vehicleId]);

  let total_ac = 0;
  if (assignRes.rows.length > 0) {
    const meters = assignRes.rows.map(r => r.meter_id);
    const acRes = await query(`SELECT COALESCE(SUM(sum_kwh),0) AS total_ac
      FROM hourly_aggregates
      WHERE entity_type='meter' AND entity_id = ANY($1::text[]) AND hour_ts >= $2 AND hour_ts <= $3`, [meters, from, to]);
    total_ac = acRes.rows[0].total_ac || 0;
  }

  const efficiency = total_ac > 0 ? (Number(total_dc) / Number(total_ac)) : null;

  return { vehicleId, total_ac: Number(total_ac), total_dc: Number(total_dc), efficiency, avg_battery_temp: avg_battery_temp ? Number(avg_battery_temp) : null };
}
