import express from 'express';
import telemetryRoutes from './routes/telemetry.routes.js';
import analyticsRoutes from './routes/analytics.routes.js';

const app = express();
app.use(express.json());

app.use('/v1/telemetry', telemetryRoutes);
app.use('/v1/analytics', analyticsRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'internal' });
});

export default app;
