import { query } from '../config/db.js';

export async function upsertLive(meterId, kwhConsumedAc, voltage, ts) {
  return query(`INSERT INTO meter_live(meter_id, kwh_consumed_ac, voltage, ts)
    VALUES($1,$2,$3,$4) ON CONFLICT (meter_id) DO UPDATE SET kwh_consumed_ac = EXCLUDED.kwh_consumed_ac, voltage = EXCLUDED.voltage, ts = EXCLUDED.ts`, [meterId, kwhConsumedAc, voltage, ts]);
}
