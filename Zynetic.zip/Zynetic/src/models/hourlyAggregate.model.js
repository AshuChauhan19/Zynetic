import { query } from '../config/db.js';

export async function addMeterAggregate(entityId, hourTs, kwh) {
  return query(`INSERT INTO hourly_aggregates(entity_type, entity_id, hour_ts, sum_kwh)
    VALUES('meter',$1,$2,$3) ON CONFLICT (entity_type, entity_id, hour_ts) DO UPDATE SET sum_kwh = hourly_aggregates.sum_kwh + EXCLUDED.sum_kwh`, [entityId, hourTs, kwh]);
}

export async function addVehicleAggregate(entityId, hourTs, kwh, batteryTemp) {
  return query(`INSERT INTO hourly_aggregates(entity_type, entity_id, hour_ts, sum_kwh, sum_battery_temp, cnt)
    VALUES('vehicle',$1,$2,$3,$4,1) ON CONFLICT (entity_type, entity_id, hour_ts) DO UPDATE SET
      sum_kwh = hourly_aggregates.sum_kwh + EXCLUDED.sum_kwh,
      sum_battery_temp = hourly_aggregates.sum_battery_temp + EXCLUDED.sum_battery_temp,
      cnt = hourly_aggregates.cnt + 1`, [entityId, hourTs, kwh, batteryTemp]);
}
