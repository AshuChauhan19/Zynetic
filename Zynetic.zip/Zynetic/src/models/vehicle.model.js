// lightweight model helpers for vehicle
import { query } from '../config/db.js';

export async function upsertLive(vehicleId, soc, kwhDeliveredDc, batteryTemp, ts) {
  return query(`INSERT INTO vehicle_live(vehicle_id, soc, kwh_delivered_dc, battery_temp, ts)
    VALUES($1,$2,$3,$4,$5) ON CONFLICT (vehicle_id) DO UPDATE SET soc = EXCLUDED.soc, kwh_delivered_dc = EXCLUDED.kwh_delivered_dc, battery_temp = EXCLUDED.battery_temp, ts = EXCLUDED.ts`, [vehicleId, soc, kwhDeliveredDc, batteryTemp, ts]);
}
