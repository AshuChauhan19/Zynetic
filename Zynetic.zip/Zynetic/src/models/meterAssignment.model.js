import { query } from '../config/db.js';

export async function getActiveMetersForVehicle(vehicleId) {
  const res = await query(`SELECT meter_id FROM meter_assignments WHERE vehicle_id=$1 AND active=TRUE`, [vehicleId]);
  return res.rows.map(r => r.meter_id);
}
