import * as analyticsService from '../services/analytics.service.js';

export async function performance24h(req, res, next) {
  const { vehicleId } = req.params;
  try {
    const result = await analyticsService.performance24h(vehicleId);
    res.json(result);
  } catch (err) {
    next(err);
  }
}
