import * as telemetryService from '../services/telemetry.service.js';
import { meterSchema } from '../validations/meter.validation.js';
import { vehicleSchema } from '../validations/vehicle.validation.js';

export async function ingest(req, res, next) {
  const payload = req.body;
  try {
    if (payload.meterId) {
      await meterSchema.validateAsync(payload);
      await telemetryService.handleMeter(payload);
      return res.status(201).json({ status: 'ok', type: 'meter' });
    }

    if (payload.vehicleId) {
      await vehicleSchema.validateAsync(payload);
      await telemetryService.handleVehicle(payload);
      return res.status(201).json({ status: 'ok', type: 'vehicle' });
    }

    return res.status(400).json({ error: 'Unknown telemetry type' });
  } catch (err) {
    next(err);
  }
}
