import express from 'express';
import { performance24h } from '../controllers/analytics.controller.js';

const router = express.Router();

router.get('/performance/:vehicleId', performance24h);

export default router;
