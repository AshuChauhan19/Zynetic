import Joi from 'joi';

export const meterSchema = Joi.object({
  meterId: Joi.string().required(),
  kwhConsumedAc: Joi.number().required(),
  voltage: Joi.number().required(),
  timestamp: Joi.date().required(),
});
