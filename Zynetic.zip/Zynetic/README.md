# Fleet Telemetry Ingest (Assessment)

## Overview
Small Node.js service demonstrating polymorphic ingestion, hot/cold data stores, and real-time analytics for EV charging fleets.

## Architecture

### Project Structure
```
src/
├── app.js                              # Express app setup
├── server.js                           # Entry point
├── config/
│   └── db.js                          # PostgreSQL connection pool
├── models/
│   ├── vehicle.model.js               # Vehicle DB helpers
│   ├── meter.model.js                 # Meter DB helpers
│   ├── hourlyAggregate.model.js       # Hourly aggregates DB helpers
│   └── meterAssignment.model.js       # Meter-to-vehicle mapping DB helpers
├── controllers/
│   ├── telemetry.controller.js        # Ingestion request handler
│   └── analytics.controller.js        # Analytics request handler
├── services/
│   ├── telemetry.service.js           # Ingestion business logic (INSERT/UPSERT)
│   └── analytics.service.js           # Analytics query logic
├── routes/
│   ├── telemetry.routes.js            # Ingest routes
│   └── analytics.routes.js            # Analytics routes
└── validations/
    ├── meter.validation.js            # Meter schema validation (Joi)
    └── vehicle.validation.js          # Vehicle schema validation (Joi)
```

## Data Flow

### Ingestion
1. **POST /v1/telemetry** → Controller validates payload → Service persists to DB
2. Meter payload: `{ meterId, kwhConsumedAc, voltage, timestamp }`
3. Vehicle payload: `{ vehicleId, soc, kwhDeliveredDc, batteryTemp, timestamp }`

### Persistence Strategy (Dual Path)
- **History (Cold)**: Append-only `meter_history`, `vehicle_history` tables — maintains 24/7 audit trail
- **Live (Hot)**: UPSERT into `meter_live`, `vehicle_live` — single row per device, always current
- **Aggregates**: Hourly bucketing (`hourly_aggregates`) to avoid full table scans on analytics queries

### Analytics
**GET /v1/analytics/performance/:vehicleId**
- Returns 24-hour summary: total AC consumed, total DC delivered, efficiency ratio, avg battery temp
- Queries only `hourly_aggregates` + `meter_assignments` lookup (no full table scans)

## Quick Start

### 1. Environment
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
# Edit .env with your Postgres credentials
```

### 2. Dependencies
```bash
npm install
```

### 3. Database
Apply the schema and migrations:
```bash
psql "host=localhost user=postgres dbname=fleet_db" -f migrations.sql
```

Or manually execute `migrations.sql` in your Postgres client.

### 4. Run
```bash
npm start
```

Dev mode with auto-reload:
```bash
npm run dev
```

Server starts on `$PORT` (default `3000`).

## Endpoints

### Ingestion
```bash
# Meter payload
curl -X POST http://localhost:3000/v1/telemetry \
  -H 'Content-Type: application/json' \
  -d '{
    "meterId": "meter-1",
    "kwhConsumedAc": 14.5,
    "voltage": 230,
    "timestamp": "2026-02-10T12:00:00Z"
  }'

# Vehicle payload
curl -X POST http://localhost:3000/v1/telemetry \
  -H 'Content-Type: application/json' \
  -d '{
    "vehicleId": "veh-1",
    "soc": 75,
    "kwhDeliveredDc": 12.3,
    "batteryTemp": 32,
    "timestamp": "2026-02-10T12:00:00Z"
  }'
```

### Analytics
```bash
# Get 24h performance for a vehicle
curl http://localhost:3000/v1/analytics/performance/veh-1
```

Example response:
```json
{
  "vehicleId": "veh-1",
  "total_ac": 14.5,
  "total_dc": 12.3,
  "efficiency": 0.848,
  "avg_battery_temp": 32.5
}
```

## Meter-to-Vehicle Mapping

Correlate AC (from meter) with DC (from vehicle) by inserting into `meter_assignments`:
```sql
-- Assign meter-1 to vehicle veh-1
INSERT INTO meter_assignments(meter_id, vehicle_id, active)
VALUES('meter-1', 'veh-1', true)
ON CONFLICT (meter_id) DO UPDATE
SET vehicle_id = EXCLUDED.vehicle_id, active = EXCLUDED.active, updated_at = now();
```

Analytics queries use this mapping to sum AC for assigned meters when computing efficiency.

## Database Schema

### Tables
- **meter_history** (append-only): meter_id, kwh_consumed_ac, voltage, ts
- **vehicle_history** (append-only): vehicle_id, soc, kwh_delivered_dc, battery_temp, ts
- **meter_live** (upsert): meter_id (PK), kwh_consumed_ac, voltage, ts
- **vehicle_live** (upsert): vehicle_id (PK), soc, kwh_delivered_dc, battery_temp, ts
- **hourly_aggregates** (upsert, indexed): entity_type, entity_id, hour_ts, sum_kwh, sum_battery_temp, cnt
- **meter_assignments**: meter_id (PK), vehicle_id, active, updated_at

## Tech Stack
- **Framework**: Node.js (ES6 modules)
- **Web**: Express.js
- **Database**: PostgreSQL
- **Validation**: Joi
- **Config**: dotenv
- **Dev**: nodemon

## Key Design Patterns
1. **Separation of Concerns**: Controllers → Services → Models → DB
2. **Dual-Path Persistence**: History (audit) + Live (current state)
3. **Pre-aggregation**: Hourly bucketing prevents full table scans
4. **Validation at Entry**: Joi schemas in controllers before service calls
5. **ES6 Modules**: Clean import/export, no CommonJS duplication
